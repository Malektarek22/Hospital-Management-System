package hospitalClasses;


public class Feedback {
    private int id;
    private String PatientName;
    private int rating;
    private String Descripton;
    private String Type;

    public Feedback(int id, String PatientName, int rating, String Descripton, String Type) {
        this.id = id;
        this.PatientName = PatientName;
        this.rating = rating;
        this.Descripton = Descripton;
        this.Type = Type;
    }

    public Feedback() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String PatientName) {
        this.PatientName = PatientName;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getDescripton() {
        return Descripton;
    }

    public void setDescripton(String Descripton) {
        this.Descripton = Descripton;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }
    
    
    
}
