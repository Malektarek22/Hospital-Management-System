package hospitalClasses;


public class Rooms {
    private int Number;
    private String type;
    private String location;

    public Rooms(int Number, String type, String location) {
        this.Number = Number;
        this.type = type;
        this.location = location;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int Number) {
        this.Number = Number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
    
    
}
