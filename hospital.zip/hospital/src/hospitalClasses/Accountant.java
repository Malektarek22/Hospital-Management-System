package hospitalClasses;


public class Accountant {
    private int ID;
    private String Name;
    private int PhoneNum;
    private String Gender;
    private String Email;
    private int Age;
    private int ReceiptNum;

    public Accountant(int ID, String Name, int PhoneNum, String Gender, String Email, int Age, int ReceiptNum) {
        this.ID = ID;
        this.Name = Name;
        this.PhoneNum = PhoneNum;
        this.Gender = Gender;
        this.Email = Email;
        this.Age = Age;
        this.ReceiptNum = ReceiptNum;
    }

    public Accountant() {
    }
    

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getPhoneNum() {
        return PhoneNum;
    }

    public void setPhoneNum(int PhoneNum) {
        this.PhoneNum = PhoneNum;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public int getReceiptNum() {
        return ReceiptNum;
    }

    public void setReceiptNum(int ReceiptNum) {
        this.ReceiptNum = ReceiptNum;
    }
    
    
}
