package hospitalClasses;


public class Doctor extends User {
    
    private String Specialization;

    public Doctor(String Specialization, int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        super(ID, Name, PhoneNum, Gender, Email, Age);
        this.Specialization = Specialization;
    }

    public String getSpecialization() {
        return Specialization;
    }

    public void setSpecialization(String Specialization) {
        this.Specialization = Specialization;
    }
    
    
}
