package hospitalClasses;


public class User {
    private int ID;
    private String Name;
    private int PhoneNum;
    private String Gender;
    private String Email;
    private int Age;

    public User(int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        this.ID = ID;
        this.Name = Name;
        this.PhoneNum = PhoneNum;
        this.Gender = Gender;
        this.Email = Email;
        this.Age = Age;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getPhoneNum() {
        return PhoneNum;
    }

    public void setPhoneNum(int PhoneNum) {
        this.PhoneNum = PhoneNum;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }
    
    
}
