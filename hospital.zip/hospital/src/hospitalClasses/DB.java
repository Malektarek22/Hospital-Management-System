
package hospitalClasses;

import com.google.gson.Gson;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bson.Document;

public class DB {
    private MongoClient client;
    private MongoDatabase database;
    private MongoCollection<Document> collectionRoom;
    private MongoCollection<Document> collectionPharmacist;
    private MongoCollection<Document> collectionPatient;
    private MongoCollection<Document> collectionNurse;
    private MongoCollection<Document> collectionMedecine;
    private MongoCollection<Document> collectionManager;
    private MongoCollection<Document> collectionFeedback;
    private MongoCollection<Document> collectionDoctor;
    private MongoCollection<Document> collectionDepartment;
    private MongoCollection<Document> collectionAccountant;
    private Gson gson = new Gson();
    
    
    public DB() {
      Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.SEVERE);

        // Initialize
        client = new MongoClient("localhost",27017);
       
        database = client.getDatabase("Hospital"); // Database name
        /*database.createCollection("Doctor");
        database.createCollection("Nurse");
        database.createCollection("Manger");
        database.createCollection("Accountant");
        database.createCollection("Department");
        database.createCollection("Patient");
        database.createCollection("Pharmacist");
        database.createCollection("Medecine");
        database.createCollection("Feedback");
        database.createCollection("Pharmacist"); */
       // database.createCollection("Rooms"); 
        collectionRoom = database.getCollection("Rooms"); // Collection name
        collectionPharmacist= database.getCollection("Pharmacist"); 
        collectionPatient= database.getCollection("Patient");
        collectionNurse= database.getCollection("Nurse");
        collectionMedecine= database.getCollection("Medecine");
        collectionManager= database.getCollection("Manager");
        collectionFeedback= database.getCollection("Feedback"); 
        collectionDoctor= database.getCollection("Doctor"); 
        collectionDepartment= database.getCollection("Department"); 
        collectionAccountant= database.getCollection("Accountant"); 
    }

    // insert room:
    public void insertRoom(Rooms r) {
        collectionRoom.insertOne(Document.parse(gson.toJson(r)));
        System.out.println("room inserted.");
    }
    
    
         // delete room:   
    public void deleteRoom(String type) {
        collectionRoom.deleteOne(Filters.eq("type", type));
                System.out.println("room deleted.");
    }
    
    ////////////////////////////////////////////////////////////////////////////
    
       // insert pharmacist:
    public void insertPharmacist(Pharmacist p) {
        collectionPharmacist.insertOne(Document.parse(gson.toJson(p)));
        System.out.println("pharmacist inserted.");
    }
    
      // delete pharmacist:
     public void deletePharmacist(String name) {
        collectionPharmacist.deleteOne(Filters.eq("Name", name));
                System.out.println("pharmacist deleted.");
    }
     
     ///////////////////////////////////////////////////////////////////////////
    
     // insert patient:
    public void insertPatient(Patient pa) {
        collectionPatient.insertOne(Document.parse(gson.toJson(pa)));
        System.out.println("patient inserted.");
    }
    
      // delete patient:
     public void deletePatient(String name) {
        collectionPatient.deleteOne(Filters.eq("Name", name));
                System.out.println("patient deleted.");
    }
     
     ///////////////////////////////////////////////////////////////////////////
     
     // insert nurse:
    public void insertNurse(Nurses n) {
        collectionNurse.insertOne(Document.parse(gson.toJson(n)));
        System.out.println("nurse inserted.");
    }
    
      // delete nurse:
     public void deleteNurse(String name) {
        collectionNurse.deleteOne(Filters.eq("Name", name));
                System.out.println("nurse deleted.");
    }
     
     ///////////////////////////////////////////////////////////////////////////
     
     
    // insert medecine:
       public void insertMedecine(Medecine m) {
        collectionMedecine.insertOne(Document.parse(gson.toJson(m)));
        System.out.println("medecine inserted.");
    }
    
      // delete medecine:
     public void deleteMedecine(String name) {
        collectionMedecine.deleteOne(Filters.eq("name", name));
                System.out.println("medecine deleted.");
    }
    
     ///////////////////////////////////////////////////////////////////////////
    
        // insert manager:
       public void insertManager(Manager m) {
        collectionManager.insertOne(Document.parse(gson.toJson(m)));
        System.out.println("manager inserted.");
    }
    
      // delete manager:
     public void deleteManager(String name) {
        collectionManager.deleteOne(Filters.eq("name", name));
                System.out.println("manager deleted.");
    }
    
     ///////////////////////////////////////////////////////////////////////////
     
     // insert feedback:
       public void insertFeedback(Feedback f) {
        collectionFeedback.insertOne(Document.parse(gson.toJson(f)));
        System.out.println("feedback inserted.");
    }
    
      // delete feedback:
     public void deleteFeedback(String name) {
        collectionFeedback.deleteOne(Filters.eq("PatientName", name));
                System.out.println("feedback deleted.");
    }
    
     ///////////////////////////////////////////////////////////////////////////
     
         // insert doctor:
       public void insertDoctor(Doctor d) {
        collectionDoctor.insertOne(Document.parse(gson.toJson(d)));
        System.out.println("doctor inserted.");
    }
    
      // delete doctor:
     public void deleteDoctor(String name) {
        collectionDoctor.deleteOne(Filters.eq("Name", name));
                System.out.println("doctor deleted.");
    }
    
    ////////////////////////////////////////////////////////////////////////////
     
     // insert department:
       public void insertDepartment(Department d) {
        collectionDepartment.insertOne(Document.parse(gson.toJson(d)));
        System.out.println("department inserted.");
    }
    
      // delete department:
     public void deleteDepartment(String name) {
        collectionDepartment.deleteOne(Filters.eq("name", name));
                System.out.println("department deleted.");
    }
    
   /////////////////////////////////////////////////////////////////////////////
     
    // insert accountant:
       public void insertAccountant(Accountant a) {
        collectionAccountant.insertOne(Document.parse(gson.toJson(a)));
        System.out.println("accountant inserted.");
    }
    
      // delete accountant:
     public void deleteAccountant(String name) {
        collectionAccountant.deleteOne(Filters.eq("Name", name));
                System.out.println("accountant deleted.");
    } 
     
    ////////////////////////////////////////////////////////////////////////////
     
     
        public void close() {
        client.close();
    }
    
}

        