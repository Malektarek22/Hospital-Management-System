package hospitalClasses;


public class Nurses extends User {
     private String Department;

    public Nurses(String Department, int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        super(ID, Name, PhoneNum, Gender, Email, Age);
        this.Department = Department;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }
     
     
}
