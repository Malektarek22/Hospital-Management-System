package hospitalClasses;


public class Patient extends User{
    private String Status;
    private String History;
    private int AppointmentNum;

    public Patient(String Status, String History, int AppointmentNum, int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        super(ID, Name, PhoneNum, Gender, Email, Age);
        this.Status = Status;
        this.History = History;
        this.AppointmentNum = AppointmentNum;
    }

   

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getHistory() {
        return History;
    }

    public void setHistory(String History) {
        this.History = History;
    }

    public int getAppointmentNum() {
        return AppointmentNum;
    }

    public void setAppointmentNum(int AppointmentNum) {
        this.AppointmentNum = AppointmentNum;
    }
    
    
}
