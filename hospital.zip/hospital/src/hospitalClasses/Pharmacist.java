package hospitalClasses;


public class Pharmacist extends User{
    private int YearsOfExperience;

    public Pharmacist(int YearsOfExperience, int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        super(ID, Name, PhoneNum, Gender, Email, Age);
        this.YearsOfExperience = YearsOfExperience;
    }

    public int getYearsOfExperience() {
        return YearsOfExperience;
    }

    public void setYearsOfExperience(int YearsOfExperience) {
        this.YearsOfExperience = YearsOfExperience;
    }

    public Pharmacist(int ID, String Name, int PhoneNum, String Gender, String Email, int Age) {
        super(ID, Name, PhoneNum, Gender, Email, Age);
    }

  
    
    
    
}
