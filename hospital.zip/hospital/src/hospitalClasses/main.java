
package hospitalClasses;

import java.rmi.RemoteException;
import java.util.ArrayList;


public class main {

    /**
     * @param args the command line arguments
     *   private int Number;
    private String type;
    private String location;
     */
   
    public static void main(String[] args) throws RemoteException {
    
        
     // insertion :int ID, String Name, int PhoneNum, String Gender, String Email, int Age, int ReceiptNum
            
        // Rooms r1= new Rooms (18,"single","third floor");
        // Medecine m1 = new Medecine("High Fresh",147,"45LE",29,"25/12/2025");
        // Manager ma1=new Manager(55,"Hassan Ahmed",001451,"Male","Hahmed@gmail.com",35,5);
       //  Feedback f1= new Feedback(237,"Omar Nour",10,"very good","feedback");
        // Doctor d1 = new Doctor("Sergery",26,"Ahmed",261487,"Female","ahmed80@yahoo.com",55);
        //  Department de1= new Department(22,"Nutrition and Dietetics","Fourth Floor");
        // Accountant a1= new Accountant(47,"Rawan Osama",001170,"Female","RawanO@gmail.com",28,11);
         
          
       // Insert and Delete functions calling:
       
        DB db = new DB();
        
        // db.insertRoom(r1);
       //  db.deleteRoom("single");
       //  db.insertMedecine(m1);
       //  db.deleteMedecine("High Fresh");
       //  db.insertManager(ma1);
       //  db.deleteManager("Hassan Ahmed");
      //   db.insertFeedback(f1);
      //   db.deleteFeedback("Omar Nour");
       //  db.insertDoctor(d1);
       //  db.deleteDoctor("Ahmed");
       //  db.insertDepartment(de1);
       //  db.deleteDepartment("Nutrition and Dietetics");
       //db.insertAccountant(a1);
      // db.deleteAccountant("Rawan Osama");
       
       
       
       
       
        
        
        
        
        
        
        
        
        
        
        
        
        

    }
  
}
