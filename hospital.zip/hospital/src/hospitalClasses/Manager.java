package hospitalClasses;


public class Manager {
    private int id;
    private String name;
    private int PhoneNum;
    private String gender;
    private String email;
    private int age;
    private int Department;

    public Manager(int id, String name, int PhoneNum, String gender, String email, int age, int Department) {
        this.id = id;
        this.name = name;
        this.PhoneNum = PhoneNum;
        this.gender = gender;
        this.email = email;
        this.age = age;
        this.Department = Department;
    }

    public Manager() {
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhoneNum() {
        return PhoneNum;
    }

    public void setPhoneNum(int PhoneNum) {
        this.PhoneNum = PhoneNum;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getDepartment() {
        return Department;
    }

    public void setDepartment(int Department) {
        this.Department = Department;
    }
    
    
    
    
    
}
