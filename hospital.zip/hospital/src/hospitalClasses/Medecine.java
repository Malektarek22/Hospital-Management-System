package hospitalClasses;


public class Medecine {
    
    private String name;
    private int id;
    private String ItemPrice;
    private int Itemquantity;
    private String ExpirationDate;

    public Medecine(String name, int id, String ItemPrice, int Itemquantity, String ExpirationDate) {
        this.name = name;
        this.id = id;
        this.ItemPrice = ItemPrice;
        this.Itemquantity = Itemquantity;
        this.ExpirationDate = ExpirationDate;
    }

    public Medecine() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemPrice() {
        return ItemPrice;
    }

    public void setItemPrice(String ItemPrice) {
        this.ItemPrice = ItemPrice;
    }

    public int getItemquantity() {
        return Itemquantity;
    }

    public void setItemquantity(int Itemquantity) {
        this.Itemquantity = Itemquantity;
    }

    public String getExpirationDate() {
        return ExpirationDate;
    }

    public void setExpirationDate(String ExpirationDate) {
        this.ExpirationDate = ExpirationDate;
    }
    
    
}
